# 开题报告插图说明

正文当前使用九幅插图：非完备观测典型场景（图 1，Python / Matplotlib 绘制的两个子图）、总体研究框架（图 2）、动态高斯时序表示与可微渲染（图 3）、状态预测与观测更新（图 4）、世界动作模型交互闭环（图 5）、可靠状态表征与观测融合方案（图 6）、缺测状态预测方案（图 7）、重观测关联与可靠性加权校正（图 8）以及动作条件预测状态学习与交互闭环（图 9）。后八幅均为 LaTeX 原生矢量图。遮挡预测校正示意图暂为备用，不接入正文；上述图均保留可编辑源。正文新增配图使用代码或其他可稳定复现的方式绘制，不使用图像生成模型。图注及配套解释在正文中维护，图号以主稿编译结果为准。

## 图1 非完备观测的典型场景

用于 1.1 的选题背景，说明机械臂自身遮挡和相机转向后原目标暂时不可见两类情境。第一段概括动态环境理解与持续状态维护的总体需求，第二段结合整图简要说明观测中断及其带来的困难，场景含义由子图标题说明；图注仅保留简短名称。绘图源为 `figures/draw_observation_scenarios.py`，两个子图共用一个脚本，采用纯 2D 俯视几何图形，不使用图像生成模型。

| 子图 | 矢量文件 | 预览文件 | 含义 |
| --- | --- | --- | --- |
| (a) | `figures/scenario_arm_occlusion.pdf` | `figures/scenario_arm_occlusion.png` | 机械臂前臂截断相机到历史目标位置的视线 |
| (b) | `figures/scenario_camera_turn.pdf` | `figures/scenario_camera_turn.png` | 相机原地转向，原目标位置位于当前视野之外 |

蓝色实心圆表示当前可见物体，橙色虚线表示目标的历史位置与可能范围，不表示已知的当前真实位置。子图 (a) 的浅灰遮挡区由相机经过前臂近侧两端的切线计算，并裁切到当前视野内；子图 (b) 的灰色虚线表示原视野，蓝色边界表示当前视野。脚本检查机械臂的遮挡关系，以及历史位置在原视野内、当前视野外的关系。

在项目根目录重绘：

```sh
conda run -n main python latex/figures/draw_observation_scenarios.py
./scripts/build.sh
```

依赖 Matplotlib，脚本优先寻找常见中文字体，找不到时通过 `kpsewhich` 使用 TeX Live 自带的 FandolHei。场景位置、视野角度、颜色、尺寸与线型集中在脚本开头。输出目录相对脚本定位，可从其他目录运行；PDF 元数据固定，便于迭代比较。正文以两个 `subfigure` 引用独立 PDF，自动生成 (a)、(b) 及子标题，整图标签为 `fig:observation-scenarios`。

## 图2 总体研究框架图

项目内路径：`figures/research_framework.tex`

用途：在第二部分 2.1 中概括总体研究目标、四项研究内容及其对应的关键科学问题。

框架采用三层四列布局：上层为统一目标，中层为四项研究内容及方法重点，下层为对应科学问题。纵向箭头表示目标分解与问题对应；横向实线表示可靠状态表征、缺测预测与重观测校正的递进关系，虚线表示向动作条件交互的扩展。文字凝练自 2.2 和 2.3，后续调整研究内容时同步维护。

图形直接通过 `\input{figures/research_framework.tex}` 参与主稿编译，依赖 TikZ 与 `arrows.meta`，已在项目样式中加载。图形、文字和连线保持矢量形式，可按列修改名称与描述，无需重新生成位图。

## 图3 动态高斯的时序表示与可微渲染

项目内路径：`figures/dynamic_scene_theory.tex`

用于 3.1.1，说明同一组高斯随时间发生位置、旋转及尺度变化，以及给定时刻的场景与相机参数如何通过投影和不透明度累积形成图像。上排椭圆为三维高斯的示意投影，同色单元表示跨时刻对应，灰色单元表示静态背景；下排给出可微渲染的信息流。图形为数学关系示意，不表示实测重建结果。

所有位置、旋转角、椭圆尺寸和颜色均固定在源文件中，不含随机过程。通过 `\input{figures/dynamic_scene_theory.tex}` 随主稿编译，使用项目已有 TikZ 与 `arrows.meta`，无需额外依赖或图片生成步骤。

## 图4 非完备观测下的状态预测与观测更新

项目内路径：`figures/belief_prediction_theory.tex`

用于 3.1.2，说明上一时刻信念经状态转移得到预测信念，再根据观测是否可用进行更新或保留预测。有新观测时，预测信念与观测共同形成更新后的信念；整个时刻无新观测时，直接保留预测。两条分支的结果均用于下一时刻递推；部分观测依据可用证据更新，其信息条件由正文解释。

图形仅表达状态估计的基本关系，不规定网络结构或实验结果。所有坐标、尺寸和颜色均固定，通过 `\input{figures/belief_prediction_theory.tex}` 随主稿编译为矢量，无需额外依赖。

## 图5 世界动作模型的交互闭环示意

项目内路径：`figures/state_action_theory.tex`

用于 3.1.3，以六个功能节点表示当前状态、世界动作模型、真实环境、新观测、状态更新和下一时刻状态。模型内部用虚线连接动作条件预测与动作生成，表示二者通过学习或动作选择建立联系；实线表示动作执行、预测状态传递和环境观测反馈。预测状态与新观测共同进入更新环节，更新后的状态用于下一轮交互。图中仅保留任务条件与必要状态符号，不展开具体网络或规划过程。

布局、颜色、文字与符号均在源文件中固定，通过 `\input{figures/state_action_theory.tex}` 随主稿编译为矢量。三幅理论图均不规定具体网络结构，后续公式或符号调整时同步维护。

## 图6 可靠状态表征与观测融合的拟定方案

项目内路径：`figures/state_fusion_method.tex`

用于 3.2.1，呈现观测筛选与稳健加权、稀疏运动节点、时间高斯过程、局部运动混合、高斯场景与可微渲染的关系。节点邻接图、支持时刻残差曲线和高斯椭圆说明各模块维护的表示；下排以对应、渲染、GP 及局部结构约束组织联合优化。实线表示证据与状态的信息传递，赭色虚线表示运动和高斯参数共同更新，与后续缺测预测或交互反馈的含义区分。

图中给出拟研究的方法组织，不表示已验证的完整系统或实验结果。GP 曲线为固定示意，仅覆盖支持时刻区间，不表示未来外推或已校准的后验方差；局部结构约束的形式继续随方案讨论细化。所有坐标、曲线、文字及形状均保留在源文件中，通过 `\input{figures/state_fusion_method.tex}` 随主稿编译，无需额外生成图片。

3.2 各分项采用“一项方案配一幅方法图”的组织方式，围绕输入输出、关键表示、模块联系与约束展开，正文和公式解释图中机制。3.2.2、3.2.3、3.2.4 已分别配缺测演化与预测、重观测关联与校正、动作条件预测状态学习与交互图，均沿用可复现矢量源与统一配色。

## 图7 历史与结构约束下的缺测状态预测方案

项目内路径：`figures/missing_prediction_method.tex`

用于 3.2.2。上排以截止时刻和时间轴区分历史观测与缺测预测；右侧固定曲线示意同一历史下的可能轨迹，不表示实测预测或已校准的置信区间。下排给出单个预测器的历史输入、两层 GRU、两轮节点消息传递、运动增量均值与方差、位姿递推。赭色虚线将预测运动传回同一网络，表示缺测期间的多步滚动，不接入未来观测。

正文初步采用三个独立预测器，沿每条采样轨迹固定模型并采样增量，将节点运动传递到高斯场景。图中简记均值与方差，完整六维增量及训练目标在正文公式中定义。八个历史时刻、两层编码、128 维特征等均属拟采用配置。所有坐标、曲线、节点与文字固定，通过 `\input{figures/missing_prediction_method.tex}` 随主稿编译为矢量，不需要图像生成工具。

## 图8 重观测关联与可靠性加权校正方案

项目内路径：`figures/reobservation_correction_method.tex`

用于 3.2.3。左列分别给出带有预测范围的历史先验和当前新证据，中列表示几何、外观、局部结构及可靠性共同参与候选评分，保留可信、歧义与未匹配分支；右列表示可靠性加权校正、运动与高斯参数的分阶段更新。顶部赭色虚线仅表示最近四个已接收时刻内至多三轮的交替计算，不提前接入未来观测，也不把同一测量重复视为独立证据。椭圆与位移仅为示意，不表示实测后验范围。

所有坐标、候选连线、图形及文字固定，通过 `\input{figures/reobservation_correction_method.tex}` 随主稿编译。网络维度、候选数量及窗口均为拟采用配置。

## 图9 动作条件预测状态学习与交互闭环方案

项目内路径：`figures/action_predictive_state_method.tex`

用于 3.2.4。主路径依次表示持续状态、动作条件转移、门控观测更新、动作读出与环境执行；上方单独接入已执行动作和当前可用观测，特征读出由预测状态产生，早于当前视觉更新。顶部虚线只表示训练时与冻结目标特征比较，不把目标特征提前送入转移。底部给出保留状态、执行动作和新观测进入下一控制步的反馈关系。

图中 16 个 256 维状态单元、两层四头转移等均为初始配置；规则网格仅示意状态组织。侧边回线表示推进到下一控制时刻，当前观测仍从上方接入更新分支。通过 `\input{figures/action_predictive_state_method.tex}` 随主稿编译，所有位置、线型与文字固定，保留可编辑矢量源。

## 备用遮挡预测校正示意图（正文未使用）

由 Python / Matplotlib 绘制的三个 2D 子图，曾用于第三部分说明总体路线与四项内容的对应。2026-10-14 清理具体方案时暂退出正文，绘图脚本及三个子图保留备用。

绘图源：`figures/draw_occlusion.py`，三个子图统一由此脚本分别绘制。

| 子图 | 矢量文件 | 预览文件 | 含义 |
| --- | --- | --- | --- |
| (a) | `figures/occlusion_visible.pdf` | `figures/occlusion_visible.png` | 左侧可见，形成观测历史 |
| (b) | `figures/occlusion_hidden.pdf` | `figures/occlusion_hidden.png` | 进入墙后遮挡区，基于历史预测 |
| (c) | `figures/occlusion_corrected.pdf` | `figures/occlusion_corrected.png` | 预测尚未穿出遮挡区，真实目标加速提前出现并被校正 |

场景为纯 2D 俯视布局。相机位于下方中央、朝向上方；墙体位于相机前方，沿水平方向展开；圆形表示目标位置，沿墙体后方的同一条水平路线从左向右移动。三幅图共享场景参数、范围与比例，图内不增加立体物体或文字。坐标仅用于表达布局，不表示实测尺度。

遮挡范围由相机经墙体近侧两端的切线计算，浅灰色区域仅绘制在墙后。子图 (b) 的蓝色实线在遮挡入口处结束，橙色虚线从该入口开始并止于预测位置；朝向隐藏目标的视线在墙前停止，不穿墙。子图 (c) 表示重观测时刻：橙色虚线与虚线圆是按匀速或减速假设推演的先验，仍处于遮挡区内、尚未完全运动出来；绿色目标表示真实运动加速后提前穿出并被再次观测，绿色箭头表示新观测把状态校正到实际位置。橙色先验轨迹止于遮挡区，不进入右侧可见区。

在项目根目录重新绘图并编译：

```sh
conda run -n main python latex/figures/draw_occlusion.py
./scripts/build.sh
```

依赖 Matplotlib。修改脚本开头的相机、墙体、目标位置、颜色、尺寸或线型参数即可迭代；脚本会检查三个阶段的可见性次序，并从自身位置定位输出目录，因此也可从其他工作目录通过绝对路径运行。

原接入方式为以 `subfigure` 环境引用三个 PDF（自动生成 (a)、(b)、(c) 及子标题），整图标签为 `fig:occlusion`，通过 `\subref` 引用对应子图；当前接入代码已随具体方案移除。已经生成的 PDF 与 PNG 随源码保留，日常编译无需 Matplotlib 或 conda。

## 概念插图（正文未使用，备用）

项目内路径：`figures/state_prediction_loop.png`

用途：在总体技术路线中说明历史观测、内部状态、未来预测和观测修正的功能关系。

生成提示词：

```text
Use case: scientific-educational.
Asset type: a text-free scientific illustration for the technical-route section of a Chinese doctoral thesis proposal.
Primary request: show historical observations forming an internal dynamic state, projecting it forward, and correcting that state with a new observation.
Style: match a restrained academic orthographic 3D illustration, white background, thin crisp grey linework, blue for observed geometry, amber for predicted geometry, green for correction. Wide horizontal composition about 2.7:1. Minimal shading. No decorative elements.
Composition: left group is a small line-art camera beside three slightly staggered image planes showing a blue cube at successive positions near a light-grey occluder. A thin grey arrow leads to the center: a compact blue 3D point cloud/cube wireframe on a light-grey local coordinate floor, with a few motion traces showing history, visually representing a structured internal state. A thin grey arrow leads to the right: two amber dashed ghost cube/point-cloud positions along a short curved trajectory, representing successive future predictions. Under the right and central groups, a single small new-observation image plane containing a solid blue cube feeds a curved green arrow back to the central state. The returned arrow should point into the central point-cloud state and have one obvious arrowhead; distinguish this correction path from the top forward path. All arrows connect content groups cleanly; no disconnected branches.
Constraints: absolutely no text, no titles, no subheadings, no letters, no numeric labels, no legends, no watermark, no equation, no infographic text boxes. No claim of a specific network architecture or measured result. Keep the observation-to-state-to-prediction path visually dominant and the new-observation correction loop simple and legible when scaled down.
```
