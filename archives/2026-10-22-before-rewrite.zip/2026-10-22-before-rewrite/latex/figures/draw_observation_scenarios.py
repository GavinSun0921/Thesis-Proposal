#!/usr/bin/env python3
"""用可编辑的 2D 几何图形分别绘制 1.1 的两个应用场景。"""

from math import atan2, cos, degrees, radians, sin
from pathlib import Path
import shutil
import subprocess

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Circle, Ellipse, FancyArrowPatch, Polygon, Rectangle, Wedge


# 两个子图共享尺寸、字体及颜色；子图编号与标题由 LaTeX 管理。
FIGURE_SIZE = (3.9, 2.9)
X_LIMITS, Y_LIMITS = (-0.35, 6.3), (-0.25, 4.45)
BLUE, AMBER = "#2474B5", "#D68A16"
INK, GREY, SHADOW = "#46515D", "#A4ADB5", "#E7EAED"
DASHES = (0, (3, 2))
FONT_SIZE, PREVIEW_DPI = 12, 240

# (a) 俯视：水平前臂截断相机与历史目标位置之间的视线。
ARM_CAMERA = (2.75, 0.35)
ARM_LEFT, ARM_RIGHT, ARM_FRONT, ARM_DEPTH = 2.10, 4.65, 2.05, 0.30
LAST_TARGET = (2.75, 3.22)
POSSIBLE_TARGET = (3.45, 3.35)

# (b) 相机原地转向：历史位置在原视野中、在新视野外。
TURN_CAMERA = (3.0, 0.35)
OLD_VIEW, NEW_VIEW = (96.0, 146.0), (36.0, 86.0)
OLD_TARGET = (1.42, 3.03)


def configure_font():
    """优先使用常见中文字体；TeX Live 的 Fandol 是跨平台回退。"""
    for family in ("PingFang SC", "Heiti SC", "Noto Sans CJK SC", "Microsoft YaHei", "SimHei"):
        try:
            font_manager.findfont(family, fallback_to_default=False)
            plt.rcParams["font.family"] = family
            return
        except ValueError:
            continue
    if shutil.which("kpsewhich"):
        path = subprocess.check_output(
            ["kpsewhich", "FandolHei-Regular.otf"], text=True,
        ).strip()
        if path:
            font_manager.fontManager.addfont(path)
            plt.rcParams["font.family"] = font_manager.FontProperties(fname=path).get_name()
            return
    raise RuntimeError("需要中文字体，如 Noto Sans CJK SC，或 TeX Live 自带的 FandolHei。")


def canvas():
    fig, ax = plt.subplots(figsize=FIGURE_SIZE)
    fig.subplots_adjust(left=0.015, right=0.985, bottom=0.015, top=0.985)
    ax.set(xlim=X_LIMITS, ylim=Y_LIMITS, aspect="equal")
    ax.set_axis_off()
    return fig, ax


def label(ax, text, xy, color=INK, **kwargs):
    ax.text(*xy, text, color=color, fontsize=FONT_SIZE, ha="center", va="center", **kwargs)


def arrow(ax, start, end, color=INK, **kwargs):
    ax.add_patch(FancyArrowPatch(start, end, arrowstyle="-|>", mutation_scale=10,
                               color=color, lw=1.0, shrinkA=0, shrinkB=0, **kwargs))


def camera(ax, point, heading=90):
    # 镜头顶端即几何计算使用的相机中心。
    cx, cy = point
    angle = radians(heading - 90)

    def transform(points):
        return [(cx + x * cos(angle) - y * sin(angle),
                 cy + x * sin(angle) + y * cos(angle)) for x, y in points]

    ax.add_patch(Polygon(transform([(-0.24, -0.47), (0.24, -0.47),
                                    (0.24, -0.17), (-0.24, -0.17)]),
                         closed=True, facecolor="white", edgecolor=INK, lw=1.1, zorder=9))
    ax.add_patch(Polygon(transform([(-0.14, -0.17), (0.14, -0.17),
                                    (0.09, 0.0), (-0.09, 0.0)]),
                         closed=True, facecolor=GREY, edgecolor=INK, lw=1.0, zorder=9))


def historical_target(ax, center):
    ax.add_patch(Circle(center, 0.20, facecolor="white", edgecolor=AMBER,
                        lw=1.5, linestyle=DASHES, zorder=7))


def draw_arm_occlusion():
    fig, ax = canvas()
    cx, cy = ARM_CAMERA
    view = Polygon([(cx, cy), (0.45, 4.25), (5.05, 4.25)], closed=True,
                   facecolor="#F0F6FA", edgecolor="#A8C5DA", lw=0.8, zorder=0)
    ax.add_patch(view)

    # 阴影由前臂近侧两端的切线定义，只保留当前视锥内部的部分。
    far_y = 4.25
    scale = (far_y - cy) / (ARM_FRONT - cy)
    far_left, far_right = (cx + (x - cx) * scale for x in (ARM_LEFT, ARM_RIGHT))
    shadow = Polygon([(ARM_LEFT, ARM_FRONT), (ARM_RIGHT, ARM_FRONT),
                      (far_right, far_y), (far_left, far_y)], closed=True,
                     facecolor=SHADOW, edgecolor="none", zorder=1)
    ax.add_patch(shadow)
    shadow.set_clip_path(view)

    # 可见的另一物体保留为蓝色实心，便于区分遮挡区和可观测区。
    ax.add_patch(Circle((1.40, 3.16), 0.20, color=BLUE, zorder=5))
    historical_target(ax, LAST_TARGET)
    ax.add_patch(Ellipse(POSSIBLE_TARGET, 1.05, 0.63, angle=12,
                         facecolor="none", edgecolor=AMBER, lw=1.15,
                         linestyle=DASHES, zorder=6))
    arrow(ax, (3.00, 3.25), (3.30, 3.30), color=AMBER, zorder=8)

    ax.plot([5.36, ARM_RIGHT], [1.02, 2.20], color=GREY, lw=13,
            solid_capstyle="round", zorder=4)
    ax.add_patch(Circle((5.36, 1.02), 0.30, facecolor="white", edgecolor=INK, lw=1.1, zorder=5))
    ax.add_patch(Rectangle((ARM_LEFT, ARM_FRONT), ARM_RIGHT - ARM_LEFT, ARM_DEPTH,
                           facecolor=GREY, edgecolor=INK, lw=0.8, zorder=5))
    ax.add_patch(Circle((ARM_RIGHT, 2.20), 0.15, facecolor="white", edgecolor=INK, lw=0.8, zorder=6))
    # 简化的两指夹爪位于前臂左端。
    ax.plot([ARM_LEFT, ARM_LEFT - 0.20, ARM_LEFT - 0.20], [2.27, 2.27, 2.48], color=INK, lw=1.1, zorder=6)
    ax.plot([ARM_LEFT, ARM_LEFT + 0.05, ARM_LEFT + 0.05], [2.27, 2.27, 2.48], color=INK, lw=1.1, zorder=6)

    # 被阻挡的视线在前臂前方终止，不穿过实体。
    ax.plot([cx, cx], [cy, ARM_FRONT], color=INK, lw=0.8, linestyle=(0, (2, 3)), zorder=3)
    ax.plot(cx, ARM_FRONT, "x", color=INK, ms=4, zorder=8)
    camera(ax, ARM_CAMERA)
    label(ax, "相机", (2.0, 0.18))
    label(ax, "机械臂", (5.12, 2.62))
    label(ax, "历史位置", (2.26, 3.94), color=AMBER)
    arrow(ax, (2.45, 3.73), (2.67, 3.44), color=AMBER, zorder=8)
    label(ax, "可能范围", (4.45, 3.94), color=AMBER)
    arrow(ax, (4.24, 3.74), (3.94, 3.52), color=AMBER, zorder=8)
    return fig


def draw_camera_turn():
    fig, ax = canvas()
    radius = 3.82
    ax.add_patch(Wedge(TURN_CAMERA, radius, *OLD_VIEW, facecolor="#F7F8F9",
                       edgecolor=GREY, lw=1.0, linestyle=DASHES, zorder=0))
    ax.add_patch(Wedge(TURN_CAMERA, radius, *NEW_VIEW, facecolor="#F0F6FA",
                       edgecolor="#A8C5DA", lw=1.0, zorder=1))
    historical_target(ax, OLD_TARGET)
    ax.add_patch(Ellipse((1.64, 3.05), 1.12, 0.68, angle=-12,
                         facecolor="none", edgecolor=AMBER, lw=1.1,
                         linestyle=DASHES, zorder=6))
    for center in ((4.45, 2.82), (3.44, 3.51)):
        ax.add_patch(Circle(center, 0.20, color=BLUE, zorder=5))

    cx, cy = TURN_CAMERA
    # 原朝向仅作为历史参照；箭头表示相机转向。
    ax.plot([cx, cx + 1.15 * cos(radians(121))],
            [cy, cy + 1.15 * sin(radians(121))], color=GREY, lw=0.9, linestyle=DASHES, zorder=3)
    start = (cx + 0.96 * cos(radians(121)), cy + 0.96 * sin(radians(121)))
    end = (cx + 0.96 * cos(radians(61)), cy + 0.96 * sin(radians(61)))
    arrow(ax, start, end, connectionstyle="arc3,rad=-0.25", zorder=8)
    camera(ax, TURN_CAMERA, heading=61)
    label(ax, "相机转向", (4.20, 0.35))
    label(ax, "原视野", (1.15, 4.20), color=INK)
    label(ax, "当前视野", (4.64, 4.20), color=BLUE)
    label(ax, "历史位置", (0.84, 2.22), color=AMBER)
    arrow(ax, (1.04, 2.43), (1.31, 2.82), color=AMBER, zorder=8)
    return fig


def main():
    # 验证示意图的可见性关系，避免改参数后误把可见区域画成缺测。
    cx, cy = ARM_CAMERA
    tx, ty = LAST_TARGET
    hit = cx + (tx - cx) * (ARM_FRONT - cy) / (ty - cy)
    if not cy < ARM_FRONT < ty or not ARM_LEFT < hit < ARM_RIGHT:
        raise ValueError("机械臂必须阻挡相机到历史目标位置的视线。")
    theta = degrees(atan2(OLD_TARGET[1] - TURN_CAMERA[1], OLD_TARGET[0] - TURN_CAMERA[0]))
    if not OLD_VIEW[0] < theta < OLD_VIEW[1] or NEW_VIEW[0] < theta < NEW_VIEW[1]:
        raise ValueError("历史位置必须位于原视野内、当前视野外。")
    configure_font()
    plt.rcParams.update({"pdf.fonttype": 42, "axes.unicode_minus": False})
    output = Path(__file__).resolve().parent
    for name, draw in (("scenario_arm_occlusion", draw_arm_occlusion),
                       ("scenario_camera_turn", draw_camera_turn)):
        fig = draw()
        fig.savefig(output / f"{name}.pdf", facecolor="white",
                    metadata={"Creator": Path(__file__).name, "CreationDate": None, "ModDate": None})
        fig.savefig(output / f"{name}.png", dpi=PREVIEW_DPI, facecolor="white",
                    metadata={"Software": Path(__file__).name})
        plt.close(fig)
        print(f"已生成：{output / name}.pdf / .png")


if __name__ == "__main__":
    main()
