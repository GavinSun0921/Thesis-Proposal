# 孙国栋博士开题报告

题目：**非完备观测下动态世界模型的状态表征与预测研究**。

报告正文以 LaTeX 为唯一维护源，工程保留一层 `latex/` 目录，入口为 [latex/main.tex](latex/main.tex)。编译结果统一放入 `latex/build/`，不再维护个人 Word 稿或重复的工程包。学校原始模板保留在 `材料/`。

**内容状态（2026-10-20）：已形成覆盖学校模板要求的完整初稿。全文围绕状态建立、缺测预测、重观测校正与交互使用统一主线，区分研究背景、公开文献、已有基础、研究目标和方案实施。第三部分保持“总—分—总”，四项方案均含方法图、优化或训练目标及验证安排；3.5 已补齐五类问题的处理措施，3.7 已归纳四项可能创新点。总体路线、运动节点监督、预测可靠性传递及交互匹配对照已补充。1.3 各项已有工作仍保留一段简要介绍；研究配置与可能贡献随实际实验结果复核。**

## 编辑位置

| 内容 | 文件 |
| --- | --- |
| 一、学位论文研究依据 | [latex/chapters/01-basis.tex](latex/chapters/01-basis.tex) |
| 二、学位论文研究内容 | [latex/chapters/02-content.tex](latex/chapters/02-content.tex) |
| 三、学位论文研究计划及预期目标 | [latex/chapters/03-plan.tex](latex/chapters/03-plan.tex) |
| 四、参考文献（输出位置） | [latex/chapters/04-references.tex](latex/chapters/04-references.tex) |
| 封面信息、勾选项及实名／匿名编译开关 | [latex/main.tex](latex/main.tex) |
| 封面、页框、表格和标题样式 | [latex/npu-report-style.sty](latex/npu-report-style.sty) |
| 学校模板的六条填写要求 | [latex/requirements.tex](latex/requirements.tex) |
| 参考文献条目 | [latex/references.bib](latex/references.bib) |
| 参考文献排版规则 | [latex/npu-gbt7714-numerical.bst](latex/npu-gbt7714-numerical.bst) |
| 文献发表状态核查 | [docs/reference_audit.md](docs/reference_audit.md) |
| 插图及生成说明 | [latex/figures/](latex/figures/) |
| 图 1 非完备观测场景（统一绘图脚本） | [latex/figures/draw_observation_scenarios.py](latex/figures/draw_observation_scenarios.py) |
| 图 2 总体研究框架图（可编辑矢量源） | [latex/figures/research_framework.tex](latex/figures/research_framework.tex) |
| 图 3 动态高斯的时序表示与可微渲染（矢量源） | [latex/figures/dynamic_scene_theory.tex](latex/figures/dynamic_scene_theory.tex) |
| 图 4 非完备观测下的状态预测与观测更新（矢量源） | [latex/figures/belief_prediction_theory.tex](latex/figures/belief_prediction_theory.tex) |
| 图 5 世界动作模型的交互闭环（矢量源） | [latex/figures/state_action_theory.tex](latex/figures/state_action_theory.tex) |
| 图 6 可靠状态表征与观测融合方案（矢量源） | [latex/figures/state_fusion_method.tex](latex/figures/state_fusion_method.tex) |
| 图 7 历史与结构约束下的缺测状态预测（矢量源） | [latex/figures/missing_prediction_method.tex](latex/figures/missing_prediction_method.tex) |
| 图 8 重观测关联与可靠性加权校正（矢量源） | [latex/figures/reobservation_correction_method.tex](latex/figures/reobservation_correction_method.tex) |
| 图 9 动作条件预测状态学习与交互闭环（矢量源） | [latex/figures/action_predictive_state_method.tex](latex/figures/action_predictive_state_method.tex) |
| 备用遮挡示意图（统一绘图脚本） | [latex/figures/draw_occlusion.py](latex/figures/draw_occlusion.py) |
| 写作约定与后续待办 | [docs/proposal_content_plan.md](docs/proposal_content_plan.md) |

第一部分按“1.1 选题背景及研究意义—1.2 国内外研究现状与发展态势—1.3 已有工作积累与研究基础”组织。1.1 从构建动态世界模型的意义出发，说明场景重建、状态维护与演化预测的关系，再以两幅可重绘的俯视子图说明机械臂自身遮挡与相机转向造成的观测缺失，并补充状态估计与视觉评测依据。1.2 按四个综述主题细分为 1.2.1—1.2.4，依次为世界模型的状态表征与预测、动态场景三维重建、运动估计与视觉跟踪、具身智能中的视觉语言动作模型与世界动作模型（WAM）。状态演化与持续记忆并入第一节，遮挡对象持续性归入第三节；第四节以世界动作模型的中英文名称和代表方法说明世界预测与动作生成、规划的结合。代表工作比较表及综合判断保留在 1.2 末尾，仅分析已有公开文献及研究问题。当前两个工作的介绍集中在 1.3，拟开展的研究内容留在第二部分。1.3 按两项已有工作细分为 1.3.1—1.3.2，依次为显式状态与连续运动（CoFuse4D）、潜在状态与交互（PS-VLA），各仅保留一段介绍，不另设综合段。

第二部分按“2.1 研究目标—2.2 研究内容—2.3 拟解决的关键科学问题”组织。2.1 明确总体目标和四项具体目标；2.2 和 2.3 各设四个 `subsubsection`，分别说明研究内容与拟研究的科学关系，研究特色融入研究内容。CoFuse4D 主要支撑第一项，PS-VLA 主要支撑第四项，并区分重建、仅依赖历史的缺测预测与重观测校正的信息条件。具体算法、对照、指标和实验流程集中在第三部分，保持研究目标、内容与科学问题的层次。已确认的术语及含义记录在写作约定中，“动作条件预测”和“状态读出”在正文首次出现时括注英文。

第三部分以模板要求为标题编排依据，保留三个模板分项标题及其字面“1./2./3.”。第 1 栏目采用“总—分—总”：“3.1 主要理论与研究方法”以动态三维场景表示与重建、动态世界模型与状态预测、动作条件预测与世界动作模型三个理论小节说明基本关系，并以研究方法收束；“3.2 技术路线与实施方案”先说明技术路线，再下设四项实施方案，与第二部分研究内容逐项对应，末尾以不编号的小结概括方案衔接与验证关系。第 2 栏目逐项对应为“3.3 研究计划可行性分析”“3.4 研究条件落实情况”“3.5 可能存在的问题及解决办法”。第 3 栏目为“3.6 研究计划”“3.7 预期成果”，将阶段安排与方法、实验及学术成果对应，并归纳四项可能创新点。3.3—3.5 分别说明理论与工作基础、可利用资源，以及五类实施问题的措施和替代安排。各模块职责详见写作约定，算法配置和评测协议随实验细化。第二、第三、第四大部分均另起新页；参考文献统一置于末尾第四部分，按正文首次引用顺序编号。

## 编译

使用 **XeLaTeX + BibTeX**，需安装包含 `latexmk` 的完整 TeX Live / MacTeX。在项目根目录运行：

```sh
./scripts/build.sh
```

[编译脚本](scripts/build.sh) 会自动定位 `latex/`，检查编译工具并完成正文及参考文献编译；在其他目录也可通过脚本的绝对路径运行。每次修改后重新运行即可，编译失败时会返回错误，成功时显示 PDF 路径。

生成的报告为 `latex/build/main.pdf`，编辑器的主文件选择 `main.tex`。[latex/.latexmkrc](latex/.latexmkrc) 已统一编译目录，中间文件无需提交到仓库。

正文插图均保留可重绘的源：总体研究框架图、3.1 的三幅理论示意图及 3.2 四项的方法图以 LaTeX 原生矢量绘制，随正文编译；背景场景与备用遮挡示意图由 Python / Matplotlib 绘制。八幅 LaTeX 图的布局、图形和文字在各自 `.tex` 源文件中维护，无需独立生成图片。3.2 各分项的网络配置均为拟采用方案，随实验结果调整。修改脚本开头的场景或样式参数后，在根目录运行对应脚本；备用遮挡图当前未接入正文：

```sh
conda run -n main python latex/figures/draw_observation_scenarios.py
conda run -n main python latex/figures/draw_occlusion.py
./scripts/build.sh
```

两个脚本分别生成背景场景的两个子图、备用遮挡示意图的三个子图，各自输出 PDF 和 PNG 到 `latex/figures/`。PDF 用于正文排版，PNG 便于预览；已生成的插图随源码保留，日常编译无需运行 Python。背景场景脚本自动寻找中文字体，也可使用 TeX Live 自带的 Fandol 回退字体。新增插图应同样保留可重绘的矢量源或脚本。

默认生成实名版。在 `main.tex` 中取消 `% \npuanonymoustrue` 这一行的注释，即生成系统送审匿名版；重新注释则恢复实名版。两种版本均编译 `main.tex`。

本地 `材料/附件3：博士开题流程说明.docx` 的“开题评议流程”要求在线申请开题抽检时，上传隐去学院、姓名、学号、导师等相关信息的报告。匿名版将学院、姓名、学号、学科专业和指导教师的填写内容留空，同时清空 PDF 属性中的作者；封面项目、日期和正文保持一致。个人信息及勾选项集中保存在 `main.tex`，无需手工删除或恢复。

中文字体默认回退到 TeX Live 自带的 Fandol，优先使用已安装的宋体、黑体和楷体；英文字体优先 Times New Roman，缺失时使用 TeX Gyre Termes。字体文件不随项目复制。

## 远端同步范围

版本控制保留报告正文、写作约定、文献核查记录、文献库、排版规则、编译配置、封面信息和正文引用的插图。[.gitignore](.gitignore) 排除 `材料/` 中的原始模板和参考报告、`tmp/` 中的临时检查文件、`latex/build/` 中的编译产物，以及系统及编辑器临时文件。这些文件保留在本地，不随仓库同步；远端源码的编译不依赖 `材料/` 或 `tmp/`。

## 模板与当前内容

版式以本年度教务系统下载的 `材料/西北工业大学研究生学位论文开题报告表.doc` 为准。保留封面字段、填写要求、三个正文栏目、研究计划表和备注栏，另将参考文献独立为第四部分。A4 纸，左右页边距 24 mm、上下 22 mm，正文边框及表格总宽 162 mm，正文小四、18 pt 行距。

课题以动态场景为研究对象，重建目标覆盖已观测内容，允许观测不足处存在缺失；评价以几何与运动一致性为重点，同时考察外观与渲染质量。正文围绕可靠状态表征与观测融合、缺测期间的状态演化与未来预测、重观测关联与持续校正、动作条件预测状态学习与交互验证四项内容展开，以 CoFuse4D 和 PS-VLA 的前期探索为基础。四项内容明确研究问题、预期能力及相互关系，3.2 四项已形成观测融合、缺测预测、重观测校正和动作条件预测状态学习的方案初稿，分别配有方法图；3.3 已依据理论、前期工作和阶段安排补充可行性分析；3.4 已据计算环境、数据和交互工程核查补充条件说明，并列举公开数据与评测资源、写入用户确认的两台 ARX 与一台 UR7e 机械臂资源，3.5 已形成问题处理和替代安排，3.7 已补充四项可能创新点，研究进度与阶段成果保持对应。正文沿用已确认的题目，当前使用非完备观测场景、总体研究框架、动态高斯时序表示与可微渲染、状态预测与观测更新、世界动作模型交互闭环、可靠状态表征与观测融合方案、缺测状态预测方案、重观测关联与校正方案、动作条件预测状态学习与交互方案九幅插图；遮挡预测校正示意图暂为备用，均保留可重绘源码。

两项工作暂用以下论文名称，均正在准备向 CVPR 2027 投稿。CVPR 属于 [CCF 推荐 A 类国际学术会议](https://www.ccf.org.cn/Academic_Evaluation/AI/zgjsjxhtjgjxshy/al/2017-04-25/592032.shtml)。

| 工作名称 | 暂定论文题目 |
| --- | --- |
| CoFuse4D | CoFuse4D: Dense Correspondence Fusion for Dynamic Gaussian Splatting |
| PS-VLA | PS-VLA: Learning Action-Conditioned Predictive States for Robotic Manipulation |

当前包含 87 条实际引用的参考文献（中文 7 条、英文 80 条）、九幅插图、一张代表工作比较表及学校要求的研究计划表。1.1 引用 10 条，1.2 引用 75 条，两节合并去重为 77 条；3.1 沿用已有理论文献，3.2.1 复用 SC-GS 与 MoSca 作为代表性对照，3.2.2 新增一条图网络动力学方法依据，并复用已有概率动力学与集成文献；3.2.3、3.2.4 复用已有的关联、状态估计、操作框架及特征预测文献。3.4 于 2026-10-20 新增 TAPVid-3D、PointOdyssey、BridgeData V2 和 DROID 四条数据集文献，并补充 LIBERO、CALVIN、SimplerEnv、RoboCasa 和 RoboTwin 五条基准文献，均采用正式出版记录，支撑数据与实验资源准备。2026-10-13 在现稿 53 条基础上新增 22 条，重点补充状态估计、遮挡对象持续性、身份关联、三维对象跟踪、对象动力学、预测校准及交互学习，并比较训练监督、推断输入与重观测后的修正条件。2026-10-15 随四个综述主题的重组增补 WAM 综述和 WorldVLA 两条文献，正文采用经核对的预印本版本。代表工作比较表逐项标注引用，状态形式使用“显式／隐式”文字分类。框架图随正文编译；横向实线表示前三项内容的递进，虚线表示向动作条件交互的扩展。页数与各部分起始页以最新编译结果为准。

文献优先采用正式出版版本，书目信息与发表状态见核查记录。2026-10-13 新增的 22 条均采用正式论文或学术专著，同时补记现稿此前增加的五条文献。中文文献保留中文作者、题名和刊名。参考文献不显示 URL 或访问日期，保留 DOI；预印本保留 arXiv 编号，仅确认录用的条目明确注明状态。原始出处 URL 作为核查元数据保留，新增条目沿用工程内统一的排版规则。

## 写作约定与后续待办

[写作约定与后续待办](docs/proposal_content_plan.md) 保留当前有效的研究范围、术语、信息边界及待完善材料；正式文字只在 LaTeX 中维护，章节结构和使用说明在本文件维护。

`docs/` 仅保留上述约定与 [文献核查记录](docs/reference_audit.md)。早期选题及研究主线讨论稿已清理，需要回顾时可通过 Git 历史查阅。
